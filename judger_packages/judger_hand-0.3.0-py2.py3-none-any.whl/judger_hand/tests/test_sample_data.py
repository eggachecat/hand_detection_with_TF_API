from unittest import TestCase
import os
from collections import Counter

import judger_hand


# TODO remove all assertRaises
class TestSampleData(TestCase):
    def test_get_file_names(self):
        imgs = judger_hand.get_file_names()
        self.assertIsInstance(imgs, list)
        self.assertTrue(all([isinstance(x, str) for x in imgs]))
        self.assertEqual(Counter([os.path.basename(x) for x in imgs]),
                         Counter(['img_002450.png', 'img_002451.png', 'img_002460.png',
                                  'img_002250.png', 'img_002251.png', 'img_002260.png',
                                  ]))
        self.assertEqual(Counter(imgs), Counter(judger_hand.get_file_names()))  # consistency
        for img in imgs:
            self.assertTrue(os.path.isfile(img) and os.access(img, os.R_OK))

    def test_get_output_file_object(self):
        f = judger_hand.get_output_file_object()
        # just check by writing something
        f.write('test'.encode('ascii'))

    def test_error_handling_of_file_object(self):
        self.assertRaises(Exception, judger_hand.judge())
        # no reinitialize module should be safe
        f = judger_hand.get_output_file_object()
        f.close()
        self.assertRaises(Exception, judger_hand.judge())

    def test_output_invalid_format(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        for img in imgs[:len(imgs) - 1]:
            f.write((img + ' 0\n').encode('ascii'))
        self.assertRaises(Exception, judger_hand.judge())

    def test_output_invalid_bbox(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        for img in imgs[:len(imgs) - 1]:
            f.write((img + ' 1 a 0 a 0 0\n').encode('ascii'))
        self.assertRaises(Exception, judger_hand.judge())

        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        for img in imgs[:len(imgs) - 1]:
            f.write((img + ' 1 1 0 0 0 0\n').encode('ascii'))
        self.assertRaises(Exception, judger_hand.judge())

    def test_output_invalid_score(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        for img in imgs[:len(imgs) - 1]:
            f.write((img + ' 1 1 2 2 0 a\n').encode('ascii'))
        self.assertRaises(Exception, judger_hand.judge())

        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        for img in imgs[:len(imgs) - 1]:
            f.write((img + ' 1 1 2 2 0 2\n').encode('ascii'))
        self.assertRaises(Exception, judger_hand.judge())

    def test_output_invalid_left_right(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        for img in imgs[:len(imgs) - 1]:
            f.write((img + ' 1 1 2 2 a 1\n').encode('ascii'))
        self.assertRaises(Exception, judger_hand.judge())

        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        for img in imgs[:len(imgs) - 1]:
            f.write((img + ' 1 1 2 2 3 1\n').encode('ascii'))
        self.assertRaises(Exception, judger_hand.judge())

    def test_average_precision(self):
        pr_all = [
            [1.0, 0.33],
            [0.5, 0.33],
            [0.67, 0.67],
            [0.5, 0.67],
            [0.6, 1.0]
        ]
        ap = judger_hand._voc_ap([x[1] for x in pr_all], [x[0] for x in pr_all])
        self.assertTrue(0.0 <= ap and ap <= 1.0)

    def test_normal_output(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        f.write((imgs[0] + ' 100 100 200 200 0 0.9\n').encode('ascii'))
        f.write((imgs[1] + ' 200 200 300 300 1 0.9\n').encode('ascii'))
        f.write((imgs[2] + ' 100 100 200 200 0 0.8\n').encode('ascii'))
        f.write((imgs[3] + ' 100 100 200 200 1 0.8\n').encode('ascii'))
        f.write((imgs[4] + ' 100 100 200 200 1 0.8\n').encode('ascii'))
        f.write((imgs[5] + ' 100 100 200 200 1 0.8\n').encode('ascii'))
        score, err = judger_hand.judge()
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(0.0 <= score and score <= 1.0)

    def test_scores_100_1(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        f.write((imgs[0] + ' 309 21 405 172 1 1.0\n').encode('ascii'))
        f.write((imgs[1] + ' 207 21 303 172 0 1.0\n').encode('ascii'))
        f.write((imgs[2] + ' 319 234 408 370 1 1.0\n').encode('ascii'))
        f.write((imgs[3] + ' 265 267 378 374 1 1.0\n').encode('ascii'))
        f.write((imgs[3] + ' 47 192 191 363 0 1.0\n').encode('ascii'))
        f.write((imgs[4] + ' 421 192 565 363 1 1.0\n').encode('ascii'))
        f.write((imgs[4] + ' 234 267 347 374 0 1.0\n').encode('ascii'))
        f.write((imgs[5] + ' 305 268 413 385 1 1.0\n').encode('ascii'))
        f.write((imgs[5] + ' 192 110 297 292 0 1.0\n').encode('ascii'))
        score, err = judger_hand.judge()
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(0.0 <= score and score <= 1.0)

    def test_scores_100_2(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        f.write((imgs[0] + ' 309 21 405 172 1 1.0\n').encode('ascii'))
        f.write((imgs[1] + ' 207 21 303 172 0 1.0\n').encode('ascii'))
        f.write((imgs[2] + ' 319 234 408 370 1 1.0\n').encode('ascii'))
        f.write((imgs[3] + ' 265 267 378 374 1 1.0\n').encode('ascii'))
        f.write((imgs[3] + ' 47 192 191 363 0 1.0\n').encode('ascii'))
        f.write((imgs[4] + ' 421 192 565 363 1 1.0\n').encode('ascii'))
        f.write((imgs[4] + ' 234 267 347 374 0 1.0\n').encode('ascii'))
        f.write((imgs[5] + ' 305 268 413 385 1 1.0\n').encode('ascii'))
        f.write((imgs[5] + ' 192 110 297 292 0 1.0\n').encode('ascii'))
        f.write((imgs[0] + ' 1 1 2 2 1 0.5\n').encode('ascii'))
        f.write((imgs[1] + ' 1 1 2 2 0 0.5\n').encode('ascii'))
        f.write((imgs[2] + ' 1 1 2 2 1 0.5\n').encode('ascii'))
        f.write((imgs[3] + ' 1 1 2 2 1 0.5\n').encode('ascii'))
        f.write((imgs[3] + ' 1 1 2 2 0 0.5\n').encode('ascii'))
        f.write((imgs[4] + ' 1 1 2 2 1 0.5\n').encode('ascii'))
        f.write((imgs[4] + ' 1 1 2 2 0 0.5\n').encode('ascii'))
        f.write((imgs[5] + ' 1 1 2 2 1 0.5\n').encode('ascii'))
        f.write((imgs[5] + ' 1 1 2 2 0 0.5\n').encode('ascii'))
        score, err = judger_hand.judge()
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(score == 1.0)

    def test_scores_100_3(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        f.write((imgs[0] + ' 309 21 405 172 1 0.5\n').encode('ascii'))
        f.write((imgs[1] + ' 207 21 303 172 0 0.5\n').encode('ascii'))
        f.write((imgs[2] + ' 319 234 408 370 1 0.5\n').encode('ascii'))
        f.write((imgs[3] + ' 265 267 378 374 1 0.5\n').encode('ascii'))
        f.write((imgs[3] + ' 47 192 191 363 0 0.5\n').encode('ascii'))
        f.write((imgs[4] + ' 421 192 565 363 1 0.5\n').encode('ascii'))
        f.write((imgs[4] + ' 234 267 347 374 0 0.5\n').encode('ascii'))
        f.write((imgs[5] + ' 305 268 413 385 1 0.5\n').encode('ascii'))
        f.write((imgs[5] + ' 192 110 297 292 0 0.5\n').encode('ascii'))
        score, err = judger_hand.judge()
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(score == 1.0)

    def test_scores_50_1(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()

        f.write((imgs[0] + ' 309 21 405 172 0 0.8\n').encode('ascii'))
        f.write((imgs[1] + ' 207 21 303 172 1 0.8\n').encode('ascii'))
        f.write((imgs[2] + ' 319 234 408 370 0 0.8\n').encode('ascii'))
        f.write((imgs[3] + ' 265 267 378 374 0 0.8\n').encode('ascii'))
        f.write((imgs[3] + ' 47 192 191 363 1 0.8\n').encode('ascii'))
        f.write((imgs[4] + ' 421 192 565 363 0 0.8\n').encode('ascii'))
        f.write((imgs[4] + ' 234 267 347 374 1 0.8\n').encode('ascii'))
        f.write((imgs[5] + ' 305 268 413 385 0 0.8\n').encode('ascii'))
        f.write((imgs[5] + ' 192 110 297 292 1 0.8\n').encode('ascii'))

        f.write((imgs[0] + ' 309 21 405 172 1 0.8\n').encode('ascii'))
        f.write((imgs[1] + ' 207 21 303 172 0 0.8\n').encode('ascii'))
        f.write((imgs[2] + ' 319 234 408 370 1 0.8\n').encode('ascii'))
        f.write((imgs[3] + ' 265 267 378 374 1 0.8\n').encode('ascii'))
        f.write((imgs[3] + ' 47 192 191 363 0 0.8\n').encode('ascii'))
        f.write((imgs[4] + ' 421 192 565 363 1 0.8\n').encode('ascii'))
        f.write((imgs[4] + ' 234 267 347 374 0 0.8\n').encode('ascii'))
        f.write((imgs[5] + ' 305 268 413 385 1 0.8\n').encode('ascii'))
        f.write((imgs[5] + ' 192 110 297 292 0 0.8\n').encode('ascii'))


        score, err = judger_hand.judge()
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(score == 0.5)

    def test_scores_50_2(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        f.write((imgs[0] + ' 309 21 405 172 0 1.0\n').encode('ascii'))
        f.write((imgs[1] + ' 207 21 303 172 1 1.0\n').encode('ascii'))
        f.write((imgs[2] + ' 319 234 408 370 0 1.0\n').encode('ascii'))
        f.write((imgs[3] + ' 265 267 378 374 1 1.0\n').encode('ascii'))
        f.write((imgs[3] + ' 47 192 191 363 0 1.0\n').encode('ascii'))
        f.write((imgs[4] + ' 421 192 565 363 1 1.0\n').encode('ascii'))
        f.write((imgs[4] + ' 234 267 347 374 0 1.0\n').encode('ascii'))
        f.write((imgs[5] + ' 305 268 413 385 1 1.0\n').encode('ascii'))
        f.write((imgs[5] + ' 192 110 297 292 0 1.0\n').encode('ascii'))
        score, err = judger_hand.judge()
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(score == 0.5)

    def test_scores_50_3(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        f.write((imgs[5] + ' 305 268 413 385 0 0.5\n').encode('ascii'))
        f.write((imgs[2] + ' 319 234 408 370 1 0.5\n').encode('ascii'))
        f.write((imgs[1] + ' 207 21 303 172 0 0.5\n').encode('ascii'))
        f.write((imgs[4] + ' 421 192 565 363 0 0.5\n').encode('ascii'))
        f.write((imgs[0] + ' 309 21 405 172 1 0.5\n').encode('ascii'))
        f.write((imgs[3] + ' 265 267 378 374 0 0.5\n').encode('ascii'))
        f.write((imgs[4] + ' 234 267 347 374 1 0.5\n').encode('ascii'))
        f.write((imgs[5] + ' 192 110 297 292 1 0.5\n').encode('ascii'))
        f.write((imgs[3] + ' 47 192 191 363 1 0.5\n').encode('ascii'))
        score, err = judger_hand.judge()
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(score == 0.5)

    def test_scores_0_1(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        f.write((imgs[0] + ' 309 21 405 172 0 1.0\n').encode('ascii'))
        f.write((imgs[1] + ' 207 21 303 172 1 1.0\n').encode('ascii'))
        f.write((imgs[2] + ' 319 234 408 370 0 1.0\n').encode('ascii'))
        f.write((imgs[3] + ' 265 267 378 374 0 1.0\n').encode('ascii'))
        f.write((imgs[3] + ' 47 192 191 363 1 1.0\n').encode('ascii'))
        f.write((imgs[4] + ' 421 192 565 363 0 1.0\n').encode('ascii'))
        f.write((imgs[4] + ' 234 267 347 374 1 1.0\n').encode('ascii'))
        f.write((imgs[5] + ' 305 268 413 385 0 1.0\n').encode('ascii'))
        f.write((imgs[5] + ' 192 110 297 292 1 1.0\n').encode('ascii'))

        score, err = judger_hand.judge()
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(score == 0.0)

    def test_scores_0_2(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        f.write((imgs[0] + ' 1 1 2 2 1 1.0\n').encode('ascii'))
        f.write((imgs[1] + ' 1 1 2 2 0 1.0\n').encode('ascii'))
        f.write((imgs[2] + ' 1 1 2 2 1 1.0\n').encode('ascii'))
        f.write((imgs[3] + ' 1 1 2 2 1 1.0\n').encode('ascii'))
        f.write((imgs[3] + ' 1 1 2 2 0 1.0\n').encode('ascii'))
        f.write((imgs[4] + ' 1 1 2 2 1 1.0\n').encode('ascii'))
        f.write((imgs[4] + ' 1 1 2 2 0 1.0\n').encode('ascii'))
        f.write((imgs[5] + ' 1 1 2 2 1 1.0\n').encode('ascii'))
        f.write((imgs[5] + ' 1 1 2 2 0 1.0\n').encode('ascii'))
        score, err = judger_hand.judge()
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(score == 0.0)

    def test_scores_others_1(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()
        f.write((imgs[0] + ' 309 21 405 172 1 1.0\n').encode('ascii'))
        f.write((imgs[1] + ' 207 21 303 172 0 1.0\n').encode('ascii'))
        f.write((imgs[3] + ' 47 192 191 363 0 1.0\n').encode('ascii'))
        f.write((imgs[4] + ' 421 192 565 363 1 1.0\n').encode('ascii'))
        score, err = judger_hand.judge()
        score1 = (0 + 1) / 2.
        score2 = 1
        score3 = 1 / 3.
        score4 = 1 / 3.
        score_gt = 0.5 * (0.5 * (score1 + score2) + 0.5 * (score3 + score4))
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(score == score_gt)

    def test_scores_others_2(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()

        f.write((imgs[1] + ' 0 0 1 1 0 0.2\n').encode('ascii'))

        f.write((imgs[0] + ' 0 0 1 1 1 0.2\n').encode('ascii'))

        f.write((imgs[5] + ' 1 1 2 2 0 0.9\n').encode('ascii'))

        f.write((imgs[5] + ' 0 0 1 1 1 0.8\n').encode('ascii'))
        f.write((imgs[5] + ' 2 2 3 3 1 0.6\n').encode('ascii'))

        f.write((imgs[1] + ' 207 21 303 172 0 0.2\n').encode('ascii'))

        f.write((imgs[0] + ' 309 21 405 172 1 0.2\n').encode('ascii'))
        f.write((imgs[2] + ' 319 234 408 370 1 0.4\n').encode('ascii'))


        f.write((imgs[3] + ' 47 192 191 363 0 1.0\n').encode('ascii'))
        f.write((imgs[4] + ' 234 267 347 374 0 1.0\n').encode('ascii'))
        f.write((imgs[5] + ' 192 110 297 292 0 1.0\n').encode('ascii'))

        f.write((imgs[3] + ' 265 267 378 374 1 0.5\n').encode('ascii'))
        f.write((imgs[4] + ' 421 192 565 363 1 0.7\n').encode('ascii'))
        f.write((imgs[5] + ' 305 268 413 385 1 0.9\n').encode('ascii'))


        score, err = judger_hand.judge()
        score1 = 0.5
        score2 = (1 + 2/3.) / 2.
        score3 = 1
        score4 = (1+ 2/3.+3/5.)/3.
        score_gt = 0.5 * (0.5 * (score1 + score2) + 0.5 * (score3 + score4))
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(score == score_gt)

    def test_scores_others_3(self):
        imgs = judger_hand.get_file_names()
        f = judger_hand.get_output_file_object()

        f.write((imgs[1] + ' 0 0 1 1 0 0.2\n').encode('ascii'))
        f.write((imgs[0] + ' 2 2 3 3 0 0.3\n').encode('ascii'))
        f.write((imgs[2] + ' 4 4 5 5 0 0.4\n').encode('ascii'))

        f.write((imgs[0] + ' 0 0 1 1 1 0.5\n').encode('ascii'))
        f.write((imgs[1] + ' 2 2 3 3 1 0.3\n').encode('ascii'))
        f.write((imgs[1] + ' 7 7 8 8 1 0.3\n').encode('ascii'))

        f.write((imgs[3] + ' 19 19 20 20 0 0.9\n').encode('ascii'))
        f.write((imgs[5] + ' 9 9 10 10 0 0.9\n').encode('ascii'))

        f.write((imgs[3] + ' 0 0 1 1 1 0.8\n').encode('ascii'))
        f.write((imgs[4] + ' 5 5 6 6 1 0.8\n').encode('ascii'))
        f.write((imgs[5] + ' 2 2 3 3 1 0.6\n').encode('ascii'))

        f.write((imgs[1] + ' 207 21 303 172 0 0.2\n').encode('ascii'))

        f.write((imgs[0] + ' 309 21 405 172 1 0.2\n').encode('ascii'))
        f.write((imgs[2] + ' 319 234 408 370 1 0.4\n').encode('ascii'))

        f.write((imgs[3] + ' 47 192 191 363 0 0.8\n').encode('ascii'))
        f.write((imgs[4] + ' 234 267 347 374 0 1.0\n').encode('ascii'))
        f.write((imgs[5] + ' 192 110 297 292 0 1.0\n').encode('ascii'))

        f.write((imgs[3] + ' 265 267 378 374 1 0.5\n').encode('ascii'))
        f.write((imgs[4] + ' 421 192 565 363 1 0.7\n').encode('ascii'))
        f.write((imgs[5] + ' 305 268 413 385 1 0.9\n').encode('ascii'))


        score, err = judger_hand.judge()
        score1 = 0.25
        score2 = (0.5+0.4)/2.
        score3 = (1. + 1. + 3/5.)/3.
        score4 = (1 + 1/2. + 1/2.)/3.
        score_gt = 0.5 * (0.5 * (score1 + score2) + 0.5 * (score3 + score4))
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(score == score_gt)


