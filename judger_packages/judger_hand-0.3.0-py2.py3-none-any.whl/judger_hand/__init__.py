from collections import defaultdict
import glob
from os import path
import tempfile
from copy import copy
from datetime import datetime
import json
import numpy as np

# _root = ''  # image root directory
_gt_all = {
    "A-L":defaultdict(list),
    "A-R":defaultdict(list),
    "B-L":defaultdict(list),
    "B-R":defaultdict(list),
}

_class = ["L", "R"]

# ground truth answers
_f = None  # the file object
_files = []  # the list of input images' file name
# _all_clas = set(
#    ['Effusion', 'Pneumothorax', 'Cardiomegaly', 'Pneumonia', 'Nodule', 'Mass', 'Atelectasis', 'Infiltrate'])
# all possible label names
_module_root = path.dirname(__file__)  # the module root


def _air_or_book(img_path):
    if img_path.split("/")[-3] == "air":
        mtype = "A"
    elif img_path.split("/")[-3] == "book":
        mtype = "B"
    else:
        mtype = "X"
    return mtype


# set up from root and ground truth file
def _setup(img_paths_str, label_paths_str):
    global _files, _gt_all
    img_paths = sorted(glob.glob(img_paths_str))
    label_paths = sorted(glob.glob(label_paths_str))
    assert len(img_paths) == len(label_paths)
    for img_path, label_path in zip(img_paths, label_paths):
        _files.append(img_path)
        json_item = json.load(open(label_path))
        for mkey, mval in json_item["bbox"].items():
            _gt_all["%s-%s"%(_air_or_book(img_path),mkey)][img_path].append([mval[0], mval[1], mval[2], mval[3]])
            # _root = image_root

            # generate files


# default setup
_setup(path.normpath(path.join(_module_root, './sample_dataset_hand/*/img/*.png')),
       path.normpath(path.join(_module_root, './sample_dataset_hand/*/label/*.json')))


def get_file_names():
    # returns a copy to prevent modification
    return copy(_files)


def get_output_file_object():
    global _f
    if _f is not None:
        _f.close()

    # uses temp file to ensure self destruction
    _f = tempfile.TemporaryFile()
    return _f


# calculates IoU of two boxes
# box = [x, y, w, h]
#def _IoU(box1, box2):
#    box1 = list(map(float, box1))
#    box2 = list(map(float, box2))
#    area1 = box1[2] * box1[3]
#    area2 = box2[2] * box2[3]
#    overlap_x = max(0.0, min(box1[0] + box1[2], box2[0] + box2[2]) - max(box1[0], box2[0]))
#    overlap_y = max(0.0, min(box1[1] + box1[3], box2[1] + box2[3]) - max(box1[1], box2[1]))
#    overlap_area = overlap_x * overlap_y
#    return overlap_area / (area1 + area2 - overlap_area)


# check if user_box matches ground truth box with target IoU (tiou)
# box = [clas, x, y, w, h]
#def _IoU(box1, box2):
#    box1 = list(map(float, box1))
#    box2 = list(map(float, box2))
#    area1 = box1[2] * box1[3]
#    area2 = box2[2] * box2[3]
#    overlap_x = max(0.0, min(box1[0] + box1[2], box2[0] + box2[2]) - max(box1[0], box2[0]))
#    overlap_y = max(0.0, min(box1[1] + box1[3], box2[1] + box2[3]) - max(box1[1], box2[1]))
#    overlap_area = overlap_x * overlap_y
#    return overlap_area / (area1 + area2 - overlap_area)
#
#
## check if user_box matches ground truth box with target IoU (tiou)
## box = [clas, x, y, w, h]
#def _box_correct(user_box, ground_box, thr):
#    return (_IoU(user_box, ground_box) >= thr)




#def _bbGt_evalRes(gt, dt, thr):
#    assert len(gt) == len(dt)
#    if len(gt) == 0:
#        return 1.0
#    pr_all = []
#    precisions = []
#    recalls = []
#    for step in [x / 10. for x in range(0, 10)]:
#        gtout = []
#        dtout = []
#        for i in range(len(gt)):
#            gti = gt[i]
#            dti = [x[:4] for x in filter(lambda x: x[-1] >= step, dt[i])]
#            gtouti, dtouti = _bbGt_evalResi(gti, dti, thr)
#            gtout += gtouti
#            dtout += dtouti
#        if len(dtout) == 0:
#            break
#        precision = sum(dtout) / max(float(len(dtout)), 1.0)
#        recall = sum(gtout) / max(float(len(gtout)), 1.0)
#        precisions.append(precision)
#        recalls.append(recall)
#    reversed(recalls)
#    AP = _voc_average_precision(recalls,precisions)
#    return AP


#def _bbGt_evalResi(gti, dti, thr):
#    gtouti = [0] * len(gti)
#    dtouti = [0] * len(dti)
#    for gi, gtii in enumerate(gti):
#        for di, dtii in enumerate(dti):
#            if _IoU(dtii, gtii) >= thr:
#                gtouti[gi] = 1
#                dtouti[di] = 1
#                break
#    return gtouti, dtouti


def _voc_eval(splitlines,class_recs ):
    npos = 0
    for item in class_recs.values():
        npos += item["bbox"].shape[0]
    image_ids = [x[0] for x in splitlines]
    confidence = np.array([float(x[1]) for x in splitlines])
    BB = np.array([[float(z) for z in x[2:]] for x in splitlines])

    nd = len(image_ids)
    tp = np.zeros(nd)
    fp = np.zeros(nd)

    if BB.shape[0] == 0:
        return 0
        # sort by confidence
    sorted_ind = np.argsort(-confidence)
    BB = BB[sorted_ind, :]
    image_ids = [image_ids[x] for x in sorted_ind]

    # go down dets and mark TPs and FPs
    for d in range(nd):
        R = class_recs[image_ids[d]]
        bb = BB[d, :].astype(float)
        ovmax = -np.inf
        BBGT = R['bbox'].astype(float)

        if BBGT.size > 0:
            # compute overlaps
            # intersection
            ixmin = np.maximum(BBGT[:, 0], bb[0])
            iymin = np.maximum(BBGT[:, 1], bb[1])
            ixmax = np.minimum(BBGT[:, 2], bb[2])
            iymax = np.minimum(BBGT[:, 3], bb[3])
            iw = np.maximum(ixmax - ixmin + 1., 0.)
            ih = np.maximum(iymax - iymin + 1., 0.)
            inters = iw * ih

            # union
            uni = ((bb[2] - bb[0] + 1.) * (bb[3] - bb[1] + 1.) +
                   (BBGT[:, 2] - BBGT[:, 0] + 1.) *
                   (BBGT[:, 3] - BBGT[:, 1] + 1.) - inters)

            overlaps = inters / uni
            ovmax = np.max(overlaps)
            jmax = np.argmax(overlaps)

        if ovmax > 0.5:
            if not R['det'][jmax]:
                tp[d] = 1.
                R['det'][jmax] = 1
            else:
                fp[d] = 1.
        else:
            fp[d] = 1.

    fp = np.cumsum(fp)
    tp = np.cumsum(tp)
    rec = tp / float(npos)
    # avoid divide by zero in case the first detection matches a difficult
    # ground truth
    prec = tp / np.maximum(tp + fp, np.finfo(np.float64).eps)
    ap = _voc_ap(rec, prec)
    return ap



def _voc_ap(rec, prec):
    # correct AP calculation
    # first append sentinel values at the end
    mrec = np.concatenate(([0.], rec, [1.]))
    mpre = np.concatenate(([0.], prec, [0.]))

    # compute the precision envelope
    for i in range(mpre.size - 1, 0, -1):
        mpre[i - 1] = np.maximum(mpre[i - 1], mpre[i])

    # to calculate area under PR curve, look for points
    # where X axis (recall) changes value
    i = np.where(mrec[1:] != mrec[:-1])[0]

    # and sum (\Delta recall) * prec
    ap = np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1])
    return ap


def judge():
    global _f, _gt_all

    submit_time = datetime.now()
    thr = 0.5
    mtypes = ["A", "B"]
    try:
        if _f is None:
            raise Exception("please call get_output_file_object() first, or please don't close the given file object")

        # flush and read from start
        _f.seek(0)

        dt_all = {
            "A-L": [],
            "A-R": [],
            "B-L": [],
            "B-R": [],
        }
        #for impath in _files:
        #    for mcls in mclass:
        #        mtype = _air_or_book(impath)
        #        dt_all[mtype][mcls][impath] = []
        while True:
            line = _f.readline().decode('ascii').strip()
            if line == '':
                break

            items = line.split(" ")
            if len(items) != 7:
                raise Exception("invalid format: %s" % line)
            bbox = []
            for i in range(1, 5):
                try:
                    bbox.append(int(items[i]))
                except:
                    raise Exception("invalid bounding-box coordinate: %s" % line)
            try:
                bbox_score = float(items[6])
            except:
                raise Exception("invalid score: %s" % line)
            if bbox_score < 0 or bbox_score > 1:
                raise Exception("invalid score: %s" % line)
            try:
                left_or_right = _class[int(items[5])]
            except:
                raise Exception("invalid left_or_right: %s" % line)

            img_path = items[0]
            air_or_book = _air_or_book(img_path)
            try:
                dt_all["%s-%s"%(air_or_book,left_or_right)].append([img_path, bbox_score] +bbox )
            except:
                raise Exception("invalid image_path: %s" % line)

        mAPs = []
        for mtype in mtypes:
            APs = []
            for mcls in _class:
                gt = _gt_all["%s-%s"%(mtype,mcls)]
                splitlines = dt_all["%s-%s"%(mtype,mcls)]
                class_rec = {}
                for img_path in _files:
                    if _air_or_book(img_path) == mtype:
                        bbox = gt[img_path]
                        class_rec[img_path] = {
                           "det":[False]*len(bbox),
                           "bbox": np.array(bbox),
                        }
                AP = _voc_eval(splitlines,class_rec)
                # fp, tp, _, _ = _bbGt_compRoc(gtout, dtout, roc=False, ref=deepcopy(ref))
                APs.append(AP)
                # _, _, _, miss = _bbGt_compRoc(gtout, dtout, roc=True, ref=deepcopy(ref))
                # miss = np.array(miss)
                # miss = np.exp(np.mean(np.log(np.maximum(miss, 1e-10))))
                # ARs.append(miss)
                # scores.append()
                #print ("%s-%s-AP:%s"%(mcls,mtype,AP ))
            mAPs.append(sum(APs) / max(float(len(APs)), 1.0))
        score = sum(mAPs) / max(float(len(mAPs)), 1.0)

        _f.close()
        _f = None

        print (json.dumps({"time": str(submit_time), "score": score}).encode('ascii'))

    except Exception as ex:
        return 0.0, str(ex)
    else:
        return score, None
