Judger
======
| The scorer of the NTU ML final project - Egocentric RGB Hand Detection.
| You must import this package and use the functions accordingly when submitting your solution.

Getting Started
===============
Please use pip or pip3 to install this package as follows.

.. code:: sh

    $pip install judger_hand-(version)-py2.py3-none-any.whl

Running the Tests
=================
Using nosetests_ to run the built-in tests is recommended.

.. _nosetests: http://nose.readthedocs.io/en/latest/

.. code:: sh

    $pip install nose
    $nosetests judger_hand

APIs
====


get_file_names()
----------------
| Returns a list of strings.
| Each string in the list is an absolute path to an input image.
| All returned strings are unique.
| This list is considered the test dataset.



get_output_file_object()
------------------------
| Returns a file-like object to which you should write your output.
| Please refer to Output Format section for the format of your output.

Speical Note
~~~~~~~~~~~~
- You must **NOT** close the returned file-like object.

judge()
-------
| Returns your score and an error message.
| If we failed to judge your output, error will be a string and score will be 0.
| Otherwise, error is None and your score will be a floating point number between 0 and 1.
| In the latter case, this function outputs a json formatted string to stdout containing your score and the submission timestamp.

Special Note
~~~~~~~~~~~~
- You should call this function **AFTER** a call to get_output_file_object().
- The timestamp generated when calling this function will be used to determine if this submission is on time.
- This function writes to stdout, you should NOT redirect stdout in your program.

Output Format
=============

Overall Structure
-----------------
The output is composed of consecutive <box block>s.

.. code:: sh

    <box block 1>
    <box block 2>
    ...
    <box block N>

- The <box block>s in the output can be at any order.
- For each input image, multiple <box block>s is possible.

Box Block
---------
Each <box block> contains the prediction of a single bounding box.

.. code:: sh

   <image file path> <x1> <y1> <x2> <y2> <class id> <score>

- <image file path> should be identical to (one of the strings of) the output of get_file_names().
- <x1>, <y1>, <x2>, and <y2> should be four non-negative integer defining a box's **top left** corner (<x1>, <y1>) and **bottom right** corner (<x2>, <y2>) respectively.
- The top left corner (**not the center of the top left pixel**) of the image is defined as (0, 0) and the bottom right corner is defined as (img_width, img_height).
- <class id> should be integer 0 or integer 1. Left hand is 0, and right hand is 1.
- <score> should be a floating number between 0~1. This score is for calculating mean average precision.
- You may output floating point numbers to any proper precision without exhausting disk, ram and run time limits, we will use python's built-in float() to convert strings to floating point numbers.


Sample Output
-------------

.. code:: sh

    /path/to/image1.png 200 50 300 150 0 0.9
    /path/to/image1.png 400 250 500 350 0 0.5
    /path/to/image2.png 300 50 400 150 1 0.8

Sample Usage
============
This code demos the functionality of this package, you are free to choose between implementing your own version and adapting this piece of code.

.. code:: python

    import judger_hand
    imgs = judger_hand.get_file_names()
    f = judger_hand.get_output_file_object()
    for img in imgs:
        img_data = read_image_by_filename(img)
        answer = inference(img_data)
        for box in answer.boxes:
            f.write('%s %d %d %d %d %d %f\n' % (img, box.x, box.y, box.w, box.h, box.class_id, box.score ))
    score, err = judger_hand.judge()
    if err is not None:  # in case we failed to judge your submission
        print err

Contact
=======

For any questions, please send an email to mark.fc_chang [at] htc [dot] com.



